import express from 'express'
import dotenv from 'dotenv'
import fs from 'node:fs'
dotenv.config({ path: '.env.local' })
dotenv.config()

const app = express()
app.use(express.json())
try { fs.mkdirSync('./logs', { recursive: true }) } catch {}

app.get('/', (_req, res) => {
  res.send('ok')
})

app.post('/api/chat', async (req, res) => {
  try {
    const { prompt } = req.body
    if (!prompt || typeof prompt !== 'string') {
      res.status(400).json({ error: 'invalid_prompt' })
      return
    }
    console.log('收到前端请求，发送给 AI 的数据是:', prompt)
    try { fs.appendFileSync('./logs/server.log', `[req] ${new Date().toISOString()} ${prompt}\n`) } catch {}
    const ascii = (s) => typeof s === 'string' && /^[\x00-\x7F]+$/.test(s)
    const validOpenAI = ascii(process.env.OPENAI_API_KEY) && process.env.OPENAI_API_KEY.startsWith('sk-')
    const provider = process.env.CHINESE_AI_PROVIDER || (validOpenAI ? 'openai:gpt-4o-mini' : (process.env.GEMINI_API_KEY ? 'gemini' : 'openrouter:deepseek-chat'))
    if (provider.startsWith('openai')) {
      const key = process.env.OPENAI_API_KEY
      if (!key) {
        res.status(200).json({
          content:
            '请在环境变量中配置 OPENAI_API_KEY。临时回答：' +
            `你问的是：“${prompt}”。这里是一个简洁的中文建议：请提供更具体的上下文与预期输出格式，以便生成更准确的内容。`,
        })
        return
      }
      const rawBase = process.env.OPENAI_API_BASE && process.env.OPENAI_API_BASE.trim()
      let base = rawBase && rawBase.length > 0 ? rawBase : 'https://api.openai.com/v1'
      if (base.includes('siliconflow.cn') && !base.includes('api.siliconflow.cn')) {
        base = 'https://api.siliconflow.cn/v1'
      }
      base = base.replace(/\/+$/,'')
      const defaultModel = base.includes('siliconflow.cn') ? 'deepseek-ai/DeepSeek-V3' : 'gpt-4o-mini'
      const model = provider.split(':')[1] || process.env.OPENAI_MODEL || defaultModel
      let r
      try {
        r = await fetch(`${base}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${key}`,
          },
          body: JSON.stringify({
            model,
            messages: [
              { role: 'system', content: '你是一个中文简历优化与职业建议助手。' },
              { role: 'user', content: prompt },
            ],
          }),
        })
      } catch (err) {
        console.error('API 返回错误详情:', err)
        try { fs.appendFileSync('./logs/server.log', `[err] ${new Date().toISOString()} ${String(err)}\n`) } catch {}
        res.status(502).json({ error: 'provider_error', detail: String(err) })
        return
      }
      if (!r.ok) {
        let detail = ''
        try { detail = await r.text() } catch {}
        console.error('API 返回错误详情:', { code: r.status, detail })
        try { fs.appendFileSync('./logs/server.log', `[err] ${new Date().toISOString()} code:${r.status} ${detail}\n`) } catch {}
        res.status(502).json({ error: 'provider_error', code: r.status, detail })
        return
      }
      const data = await r.json()
      const content =
        data?.choices?.[0]?.message?.content ??
        '未获取到有效回复，请稍后重试。'
      res.json({ content })
      return
    }
    if (provider.startsWith('openrouter')) {
      const key = process.env.OPENROUTER_API_KEY
      if (!key) {
        res.status(200).json({
          content:
            '请在环境变量中配置 OPENROUTER_API_KEY。临时回答：' +
            `你问的是：“${prompt}”。这里是一个简洁的中文建议：请提供更具体的上下文与预期输出格式，以便生成更准确的内容。`,
        })
        return
      }
      const raw = provider.split(':')[1] || 'deepseek-chat'
      const model =
        raw.includes('/') ? raw : `deepseek/${raw}`
      const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${key}`,
          'HTTP-Referer': process.env.APP_URL || 'http://localhost:3000',
          'X-Title': 'AI Resume Assistant',
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: 'system', content: '你是一个中文简历优化与职业建议助手。' },
            { role: 'user', content: prompt },
          ],
        }),
      })
      if (!r.ok) {
        let detail = ''
        try {
          detail = await r.text()
        } catch {}
        console.error('API 返回错误详情:', { code: r.status, detail })
        try { fs.appendFileSync('./logs/server.log', `[err] ${new Date().toISOString()} code:${r.status} ${detail}\n`) } catch {}
        console.error('OpenRouter error', r.status, detail)
        if (process.env.GEMINI_API_KEY) {
          const gr = await fetch(
            'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=' +
              process.env.GEMINI_API_KEY,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
              }),
            }
          )
          if (gr.ok) {
            const gdata = await gr.json()
            const gcontent =
              gdata?.candidates?.[0]?.content?.parts?.[0]?.text ??
              '未获取到有效回复，请稍后重试。'
            res.json({ content: gcontent })
            return
          }
        }
        res.status(502).json({ error: 'provider_error', code: r.status, detail })
        return
      }
      const data = await r.json()
      const content =
        data?.choices?.[0]?.message?.content ??
        '未获取到有效回复，请稍后重试。'
      res.json({ content })
      return
    }
    if (process.env.GEMINI_API_KEY) {
      let r
      try {
        r = await fetch(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=' +
          process.env.GEMINI_API_KEY,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
          }),
        }
      )
      } catch (err) {
        console.error('API 返回错误详情:', err)
        try { fs.appendFileSync('./logs/server.log', `[err] ${new Date().toISOString()} ${String(err)}\n`) } catch {}
        res.status(502).json({ error: 'provider_error', detail: String(err) })
        return
      }
      if (!r.ok) {
        console.error('API 返回错误详情:', { code: r.status })
        try { fs.appendFileSync('./logs/server.log', `[err] ${new Date().toISOString()} code:${r.status}\n`) } catch {}
        res.status(502).json({ error: 'provider_error' })
        return
      }
      const data = await r.json()
      const content =
        data?.candidates?.[0]?.content?.parts?.[0]?.text ??
        '未获取到有效回复，请稍后重试。'
      res.json({ content })
      return
    }
    res.json({
      content:
        '暂未配置可用的中文模型接口。你可以设置 OPENROUTER_API_KEY 使用 DeepSeek，或设置 GEMINI_API_KEY 使用 Gemini。当前给出一个占位回答：' +
        prompt,
    })
  } catch (e) {
    console.error('Server error', e && (e.stack || e.message || e))
    res.status(500).json({ error: 'server_error' })
  }
})

const port = process.env.PORT || 5000
app.listen(port, () => {
  process.stdout.write(`api:${port}\n`)
})
