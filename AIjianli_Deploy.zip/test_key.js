import dotenv from 'dotenv'

dotenv.config({ path: '.env.local' })
dotenv.config()

const key = process.env.OPENAI_API_KEY
const url = 'https://api.siliconflow.cn/v1/chat/completions'
const model = (process.env.OPENAI_MODEL && /^[\x00-\x7F]+$/.test(process.env.OPENAI_MODEL))
  ? process.env.OPENAI_MODEL
  : 'deepseek-ai/DeepSeek-V3'

const controller = new AbortController()
const timeout = setTimeout(() => controller.abort(), 10000)

const run = async () => {
  if (!key) {
    console.error('缺少 OPENAI_API_KEY')
    return
  }
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: 'You are a helpful assistant' },
          { role: 'user', content: 'hello' },
        ],
      }),
      signal: controller.signal,
    })
    clearTimeout(timeout)
    const text = await r.text()
    console.log('status:', r.status)
    console.log('body:', text)
  } catch (e) {
    console.error('fetch_error:', e?.message || String(e))
  }
}

run()
