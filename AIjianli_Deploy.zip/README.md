# AI Resume Assistant (AI 简历助手)

## Deployment Guide (部署指南)

### 1. Prerequisites (前置准备)
- Node.js >= 18.0.0 (推荐 Node 20+)
- npm 或 yarn/pnpm

### 2. Installation (安装)
解压 `AIjianli_Deploy.zip` 后，在项目根目录打开终端执行：
```bash
npm install
```

### 3. Configuration (配置)
复制 `.env.example` 为 `.env.local`，并填入你的 API Key：
```bash
cp .env.example .env.local
# 或者在 Windows 上直接重命名并编辑文件
```

**关键配置项**：
```env
# 必填：你的 SiliconFlow API Key
OPENAI_API_KEY=sk-xxxxxx

# 必填：API 地址 (注意必须是 /v1 结尾)
OPENAI_API_BASE=https://api.siliconflow.cn/v1

# 选填：模型名称 (默认 deepseek-ai/DeepSeek-V3)
OPENAI_MODEL=deepseek-ai/DeepSeek-V3

# 选填：指定提供商 (openai兼容模式)
CHINESE_AI_PROVIDER=openai
```

### 4. Run (启动)
#### 开发模式 (Development)
同时启动前端和后端：
```bash
npm run start:all
```
访问：http://localhost:3000

#### 生产模式 (Production)
如果需要部署到生产环境：
1. 构建前端：
   ```bash
   npm run build
   ```
   构建产物在 `dist/` 目录。
2. 启动后端：
   ```bash
   node server.js
   ```
   后端运行在 http://localhost:5000。
   (注意：生产环境通常需要反向代理将 /api 转发到后端，或者配置后端 serve 静态文件)

### 5. Troubleshooting (故障排除)
- 如果前端提示“服务不可用”：
  - 检查后端是否启动 (访问 http://localhost:5000/ 应返回 ok)
  - 检查 `.env.local` 配置是否正确
  - 查看 `logs/server.log` 获取详细错误信息
