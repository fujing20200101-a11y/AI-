import React, { useState, useEffect, useRef } from 'react';
import { 
  Layout, 
  MessageSquare, 
  Sparkles, 
  User, 
  FileText, 
  Plus, 
  Lock, 
  Send,
  ChevronRight,
  Download,
  History,
  CheckCircle2,
  MoreVertical,
  Upload,
  X,
  Trash2,
  AlertCircle,
  BarChart3,
  Search,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
type Tab = 'home' | 'ai-assistant' | 'expert';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

interface ResumeCard {
  id: string;
  title: string;
  date: string;
  isLocked?: boolean;
}

// --- Components ---

const Dashboard = ({ score = 85 }: { score?: number }) => {
  return (
    <div className="bg-white/80 backdrop-blur-md border border-slate-200 rounded-2xl p-4 shadow-sm flex items-center gap-6 mb-6">
      <div className="flex items-center gap-3">
        <div className="relative w-12 h-12">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="24"
              cy="24"
              r="20"
              stroke="currentColor"
              strokeWidth="4"
              fill="transparent"
              className="text-slate-100"
            />
            <circle
              cx="24"
              cy="24"
              r="20"
              stroke="currentColor"
              strokeWidth="4"
              fill="transparent"
              strokeDasharray={125.6}
              strokeDashoffset={125.6 * (1 - score / 100)}
              className="text-brand transition-all duration-1000 ease-out"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-brand">
            {score}%
          </div>
        </div>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">岗位匹配度</p>
          <p className="text-sm font-bold text-slate-800">匹配度极高</p>
        </div>
      </div>

      <div className="h-8 w-px bg-slate-200" />

      <div className="flex gap-3">
        {[
          { label: '关键词覆盖', status: 'success', color: 'bg-emerald-500' },
          { label: '经历完整度', status: 'warning', color: 'bg-amber-500' },
          { label: '语言专业度', status: 'success', color: 'bg-emerald-500' },
        ].map((tag, i) => (
          <div key={i} className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
            <div className={`w-1.5 h-1.5 rounded-full ${tag.color}`} />
            <span className="text-xs font-medium text-slate-600">{tag.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const Sidebar = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const resumes: ResumeCard[] = [
    { id: '1', title: '互联网大厂通用简历', date: '2024-02-28' },
    { id: '2', title: '前端开发工程师-阿里', date: '2024-02-15' },
    { id: '3', title: '游戏开发-腾讯', date: '2024-01-20' },
    { id: '4', title: '产品经理-字节', date: '2023-12-05' },
    { id: '5', title: '后端开发-美团', date: '2023-11-12' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-[60]"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 bottom-0 w-80 bg-white shadow-2xl z-[70] flex flex-col"
          >
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="font-bold text-lg">个人中心</h2>
              <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <div className="mb-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-full bg-slate-100 overflow-hidden border border-slate-200">
                    <img src="https://picsum.photos/seed/user/100/100" alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">张小明</h3>
                    <p className="text-xs text-slate-500">本科 · 计算机科学</p>
                  </div>
                </div>
                <div className="space-y-2 text-xs text-slate-500">
                  <p className="flex items-center gap-2"><Sparkles className="w-3 h-3" /> zhang.xm@example.com</p>
                  <p className="flex items-center gap-2"><Sparkles className="w-3 h-3" /> +86 138-0000-0000</p>
                </div>
              </div>

              <div className="mb-4 flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400">历史简历库</h4>
                <span className="text-[10px] font-bold text-rose-500 bg-rose-50 px-2 py-0.5 rounded-full">5/5 (已满)</span>
              </div>

              <div className="space-y-3">
                {resumes.map((resume) => (
                  <div key={resume.id} className="group p-3 border border-slate-100 rounded-xl hover:border-brand hover:bg-blue-50/30 transition-all cursor-pointer">
                    <div className="flex items-center gap-3 mb-1">
                      <FileText className="w-4 h-4 text-slate-400 group-hover:text-brand" />
                      <span className="text-sm font-medium text-slate-700 truncate">{resume.title}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-mono">{resume.date}</span>
                      <button className="opacity-0 group-hover:opacity-100 p-1 hover:text-rose-500 transition-all">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 bg-amber-50 border border-amber-100 rounded-xl">
                <div className="flex items-start gap-3 mb-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <p className="text-xs text-amber-800 font-medium leading-relaxed">
                    存储空间已满。请删除旧简历或升级 VIP 以继续保存新生成的简历。
                  </p>
                </div>
                <button className="w-full bg-amber-600 text-white py-2 rounded-lg text-xs font-bold hover:bg-amber-700 transition-colors">
                  立即升级 VIP
                </button>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100">
              <button className="w-full flex items-center justify-center gap-2 text-slate-500 hover:text-slate-800 transition-colors text-sm font-medium">
                退出登录
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

const Navbar = ({ activeTab, setActiveTab, onProfileClick }: { activeTab: Tab, setActiveTab: (t: Tab) => void, onProfileClick: () => void }) => {
  return (
    <nav className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-b border-slate-200 z-50 px-6 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center">
          <Sparkles className="text-white w-5 h-5" />
        </div>
        <span className="font-semibold text-lg tracking-tight">AI Resume</span>
      </div>

      <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
        {[
          { id: 'home', label: '首页', icon: Layout },
          { id: 'ai-assistant', label: 'AI 助手', icon: MessageSquare },
          { id: 'expert', label: '优化工作区', icon: Zap },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as Tab)}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.id 
                ? 'bg-white text-brand shadow-sm' 
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <button 
          onClick={onProfileClick}
          className="w-8 h-8 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center overflow-hidden hover:ring-2 hover:ring-brand/20 transition-all"
        >
          <img 
            src="https://picsum.photos/seed/user/100/100" 
            alt="User" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </button>
      </div>
    </nav>
  );
};

const HomeTab = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-5xl mx-auto pt-24 px-6 pb-12"
    >
      <div className="text-center mb-16">
        <h1 className="text-5xl font-bold tracking-tight mb-4">打造你的专业简历</h1>
        <p className="text-slate-500 text-lg max-w-2xl mx-auto">
          利用最先进的 AI 技术，在几分钟内生成一份极具竞争力的简历。
          从内容润色到排版优化，我们全程为你护航。
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { title: 'AI 智能生成', desc: '只需输入基本信息，AI 自动为你撰写专业描述。', icon: Sparkles },
          { title: '实时预览', desc: '所见即所得，随时调整排版与样式。', icon: FileText },
          { title: '专家审核', desc: '行业资深 HR 为你的简历提供一对一优化建议。', icon: CheckCircle2 },
        ].map((feature, i) => (
          <div key={i} className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mb-6">
              <feature.icon className="text-brand w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
            <p className="text-slate-500 leading-relaxed">{feature.desc}</p>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

const AIAssistantTab = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'assistant', content: '你好！我是你的 AI 简历助手。请告诉我你的求职意向或者上传现有简历，我会帮你进行优化。' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: userMsg.content }),
    })
      .then(async (r) => {
        let payload: any = null
        try { payload = await r.json() } catch {}
        if (!r.ok) {
          const code = payload?.code
          const detail = payload?.detail
          const content = code ? `服务暂不可用(code:${code})` + (detail ? `，原因：${detail}` : '') : '服务暂时不可用，请稍后重试。'
          const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content }
          setMessages(prev => [...prev, aiMsg])
          return
        }
        const content = payload?.content || '未获取到有效回复'
        const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content }
        setMessages(prev => [...prev, aiMsg])
      })
      .catch(() => {
        const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: '服务暂时不可用，请稍后重试。' }
        setMessages(prev => [...prev, aiMsg])
      })
      .finally(() => setIsTyping(false))
  };

  return (
    <div className="flex h-[calc(100vh-64px)] pt-16">
      {/* Left: Chat Dialog */}
      <div className="w-2/5 bg-slate-900 flex flex-col border-r border-slate-800">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <span className="text-slate-400 text-xs font-medium uppercase tracking-widest">AI 对话框</span>
          <div className="flex gap-1.5">
            <div className="w-2 h-2 rounded-full bg-slate-700" />
            <div className="w-2 h-2 rounded-full bg-slate-700" />
            <div className="w-2 h-2 rounded-full bg-slate-700" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-brand text-white' 
                    : 'bg-slate-800 text-slate-200'
                }`}>
                  {msg.content}
                </div>
              </motion.div>
            ))}
            {isTyping && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start"
              >
                <div className="bg-slate-800 text-slate-400 p-4 rounded-2xl text-sm italic flex items-center gap-2">
                  <div className="flex gap-1">
                    <span className="w-1 h-1 bg-slate-500 rounded-full animate-bounce" />
                    <span className="w-1 h-1 bg-slate-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1 h-1 bg-slate-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                  AI 正在思考...
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="p-6 bg-slate-900 border-t border-slate-800">
          <div className="relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="输入你的问题或优化建议..."
              className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-4 py-3 pr-12 text-sm focus:outline-none focus:border-brand transition-colors"
            />
            <button 
              onClick={handleSend}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-brand rounded-lg flex items-center justify-center text-white hover:bg-blue-700 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Right: A4 Preview */}
      <div className="w-3/5 bg-slate-100 overflow-y-auto p-12 flex flex-col items-center">
        <div className="w-full max-w-[210mm]">
          <Dashboard score={92} />
          <div className="a4-paper font-sans text-slate-800">
            <header className="border-b-2 border-slate-900 pb-6 mb-8 flex justify-between items-end">
              <div>
                <h1 className="text-3xl font-bold tracking-tight mb-1">张小明</h1>
                <p className="text-slate-500 text-sm">高级前端开发工程师 | 5年经验</p>
              </div>
              <div className="text-right text-xs text-slate-500 space-y-1">
                <p>Email: zhang.xm@example.com</p>
                <p>Phone: +86 138-0000-0000</p>
                <p>Github: github.com/xiaoming</p>
              </div>
            </header>

            <section className="mb-8">
              <h2 className="text-sm font-bold uppercase tracking-widest text-brand mb-4 border-b border-slate-100 pb-1">专业技能</h2>
              <div className="grid grid-cols-2 gap-y-2 text-sm">
                <p>• 精通 React, Vue, TypeScript</p>
                <p>• 熟悉 Node.js, GraphQL, Webpack</p>
                <p>• 深入理解前端工程化与性能优化</p>
                <p>• 具备大型分布式系统前端架构经验</p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-sm font-bold uppercase tracking-widest text-brand mb-4 border-b border-slate-100 pb-1">工作经历</h2>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-baseline mb-1">
                    <h3 className="font-bold text-base">某知名互联网公司</h3>
                    <span className="text-xs text-slate-500 font-mono">2021.06 - 至今</span>
                  </div>
                  <p className="text-sm font-medium text-slate-600 mb-2">高级前端开发工程师</p>
                  <ul className="text-sm text-slate-500 space-y-1 ml-4 list-disc">
                    <li>主导核心业务线前端重构，采用微前端架构提升团队协作效率 40%。</li>
                    <li>负责性能监控平台搭建，将首屏加载时间从 2.4s 降低至 0.8s。</li>
                    <li>带教 3 名初级工程师，建立团队内部组件库与开发规范。</li>
                  </ul>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

const ExpertTab = () => {
  const [isUploading, setIsUploading] = useState(false);
  const [isAnalyzed, setIsAnalyzed] = useState(false);
  const [jd, setJd] = useState('');
  const [supplement, setSupplement] = useState('');

  const handleUpload = () => {
    setIsUploading(true);
    setTimeout(() => {
      setIsUploading(false);
      alert('简历上传成功！');
    }, 2000);
  };

  const handleAnalyze = () => {
    if (!jd.trim()) return;
    setIsAnalyzed(true);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-4xl mx-auto pt-24 px-6 pb-12"
    >
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold tracking-tight mb-2">优化工作区</h2>
        <p className="text-slate-500">上传简历并输入目标岗位描述，AI 将为您进行深度对标分析</p>
      </div>

      {/* Dashboard in Workspace */}
      <AnimatePresence>
        {isAnalyzed && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
            <Dashboard score={78} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Upload Area */}
      <div 
        onClick={handleUpload}
        className={`relative group h-64 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all ${
          isUploading ? 'border-brand bg-blue-50/50' : 'border-slate-200 hover:border-brand hover:bg-slate-50'
        }`}
      >
        {isUploading ? (
          <div className="flex flex-col items-center">
            <div className="relative mb-4">
              <div className="w-16 h-16 bg-brand/10 rounded-full flex items-center justify-center animate-breathe">
                <Zap className="w-8 h-8 text-brand" />
              </div>
              <div className="absolute inset-0 border-2 border-brand rounded-full animate-ping opacity-20" />
            </div>
            <p className="text-brand font-bold">AI 正在扫描简历...</p>
          </div>
        ) : (
          <>
            <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Upload className="w-8 h-8 text-slate-400 group-hover:text-brand" />
            </div>
            <p className="text-slate-800 font-bold mb-1">点击或拖拽简历至此处上传</p>
            <p className="text-slate-400 text-sm">支持 PDF, DOCX, JPG 格式 (最大 10MB)</p>
          </>
        )}
      </div>

      {/* JD Input */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-3">
          <label className="text-sm font-bold text-slate-800">目标岗位描述 (JD)</label>
          <span className="text-[10px] text-slate-400 font-mono">粘贴职位要求以获得更精准的建议</span>
        </div>
        <div className="relative">
          <textarea
            value={jd}
            onChange={(e) => setJd(e.target.value)}
            placeholder="例如：负责公司核心业务的前端开发，精通 React 和 TypeScript，有性能优化经验优先..."
            className="w-full h-40 bg-white border border-slate-200 rounded-2xl p-4 text-sm focus:outline-none focus:border-brand transition-colors resize-none"
          />
          <button 
            onClick={handleAnalyze}
            disabled={!jd.trim()}
            className="absolute bottom-4 right-4 bg-slate-900 text-white px-6 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg"
          >
            <BarChart3 className="w-4 h-4" />
            AI 深度分析
          </button>
        </div>
      </div>

      {/* Supplementary Info */}
      <AnimatePresence>
        {isAnalyzed && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 p-6 bg-brand/5 border border-brand/10 rounded-2xl"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center">
                <Sparkles className="text-white w-4 h-4" />
              </div>
              <h3 className="font-bold text-slate-900">补充信息建议</h3>
            </div>
            <p className="text-sm text-slate-600 mb-4 leading-relaxed">
              为了提高与该岗位的匹配度，AI 建议您补充关于 <span className="font-bold text-brand">[性能优化项目]</span> 的具体细节。
              例如：您在项目中具体使用了哪些手段？带来了多少性能提升？
            </p>
            <textarea
              value={supplement}
              onChange={(e) => setSupplement(e.target.value)}
              placeholder="请在此处补充细节..."
              className="w-full h-24 bg-white border border-brand/20 rounded-xl p-3 text-sm focus:outline-none focus:border-brand transition-colors resize-none"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen">
      <Navbar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onProfileClick={() => setSidebarOpen(true)} 
      />
      
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <main>
        {activeTab === 'home' && <HomeTab />}
        {activeTab === 'ai-assistant' && <AIAssistantTab />}
        {activeTab === 'expert' && <ExpertTab />}
      </main>

      {/* Footer - Only on Home tab */}
      {activeTab === 'home' && (
        <footer className="max-w-5xl mx-auto py-12 px-6 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 opacity-50">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-medium">AI Resume Assistant © 2024</span>
          </div>
          <div className="flex gap-8 text-sm text-slate-500">
            <a href="#" className="hover:text-brand transition-colors">隐私政策</a>
            <a href="#" className="hover:text-brand transition-colors">服务条款</a>
            <a href="#" className="hover:text-brand transition-colors">联系我们</a>
          </div>
        </footer>
      )}
    </div>
  );
}
