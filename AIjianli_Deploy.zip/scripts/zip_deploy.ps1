$items = @("src", "scripts", "logs", "server.js", "server.ts", "test_key.js", "package.json", "tsconfig.json", "vite.config.ts", "index.html", ".gitignore", "README.md", ".env.example")
$files = Get-ChildItem -Path $items -ErrorAction SilentlyContinue
if ($files) {
    Compress-Archive -Path $files.FullName -DestinationPath AIjianli_Deploy.zip -Force
    Write-Host "Deploy zip created successfully at $PWD\AIjianli_Deploy.zip"
} else {
    Write-Host "No files found to zip"
}
