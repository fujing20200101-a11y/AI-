$files = Get-ChildItem -Path src, scripts, logs, *.js, *.ts, *.json, *.html, .gitignore -ErrorAction SilentlyContinue
if ($files) {
    Compress-Archive -Path $files.FullName -DestinationPath AIjianli_Source.zip -Force
    Write-Host "Zip created successfully at $PWD\AIjianli_Source.zip"
} else {
    Write-Host "No files found to zip"
}
