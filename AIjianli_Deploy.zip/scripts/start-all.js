import { spawn } from 'node:child_process'

const opts = { cwd: process.cwd(), stdio: 'inherit', shell: true, env: process.env }

const backend = spawn(process.execPath, ['server.js'], opts)
backend.on('exit', (code) => {
  process.stdout.write(`backend_exit:${code}\n`)
})

setTimeout(() => {
  const frontend = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--port=3000', '--host=0.0.0.0'], opts)
  frontend.on('exit', (code) => {
    process.stdout.write(`frontend_exit:${code}\n`)
  })
}, 500)
