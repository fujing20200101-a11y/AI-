const run = async () => {
  try {
    const r = await fetch('http://localhost:5000/api/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        prompt: '请用中文优化我的简历项目描述：React+TypeScript 开发企业级组件库',
      }),
    })
    const text = await r.text()
    console.log('status', r.status)
    console.log(text)
  } catch (e) {
    console.error('error', e)
  }
}

run()
